## Time Series

##### Example 1: Time Series Exploration and Comparison Using SAS&reg; Enterprise Miner&trade;

![alt text](../README_imgs/TimeSeriesExplore.png "Time Series Explore")

###### Goal:
The goal is to explore a time series data set and organize it into a format for further analysis that compares 
different time series in the data.

###### Files:
TimeSeriesExplore.xml, TimeSeriesExplore.pdf

***

License: <http://www.apache.org/licenses/LICENSE-2.0>